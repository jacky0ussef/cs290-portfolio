import React, { useState } from 'react';
import StaffRow from '../components/StaffRow.js';

function Staff() {

    const [data, setData] = useState([]);
    const getData = () => {
        fetch("https://randomuser.me/api/?results=10")
            .then((result) => result.json())
            .then((result) => {
                setData(result.results);
            })
            .catch(() => {
                alert("Sorry, the random user data could not be retrieved at this time.");
            });
    };

    return (
        <div>
        <h2>Directory</h2>
        <article>
            
            <p>
                <button id="serverSource" onClick={getData} value="generate">Generate</button>
                ten random people from the <a href="https://randomuser.me/" target="_blank">Random Person Generator</a> website.
            </p>
            
            <table>
                <caption>User information</caption>
                <thead>
                    <tr>
                        <th>Portrait</th>
                        <th>Name/Email</th>
                        <th>Telephone</th>
                        <th>City</th>
                    </tr>
                </thead>
                <tbody id="randomPerson">
                    {data.map((user, i) => <StaffRow user={user} key={i} />)}
                </tbody>
            </table>
        </article>
        </div>
    );
}

export default Staff;

