import React from 'react';

function Home() {
    return (
        <div>
        <h2>Welcome!</h2>
        <nav>
        </nav>
        <article>
            <h3>I am Jack, a computer science student learning web development.</h3>
            <p>Here is some information on the technological make-up of this web application.</p>
            <p>This website is written in <strong>React</strong>, which is a popular open source <strong>frontend</strong> framework that utilizes the <strong>components</strong> concept.
                This is a <strong>single-page-application</strong>, or SPA, which is written in the <strong>JavaScript</strong> language. 
                Modern JavaScript has become the go-to language for many when writing <strong>client-side</strong> and <strong>server-side</strong> programming.
                JS also allows us to directly incorporate <strong>HTML</strong>, the hypertext mark-up language that displays a web application's <strong>UI</strong> or user-interface.
                Here, <strong>optimized images</strong> are used to incorporate quick and clear background and gallery images.
                Other types of media include <strong>icons</strong> that make the UI easier to navigate and add character to a website.
                Along with HTML, Cascading Style Sheets, or <strong>CSS</strong>, handles the styling for the pages of this website.
                This includes text fonts, which in my case are imported from <strong>Google Fonts</strong>.
            </p>  
            <p>  
                I utilized <strong>Node</strong>, an environment for developing web applications with server access, and incorporated the <strong>Express</strong> framework for ease of <strong>CRUD</strong> operations.
                Data is managed with <strong>MongoDB</strong>, a <strong>document-oriented DBMS</strong> (Database Management System). MongoDB stores documents internally in <strong>BSON</strong> format, a binary form of <strong>JSON</strong>.
                Another technology incorporated for maintenance is <strong>Mongoose</strong>, a JavaScript library that makes MongoDB interaction much simpler.
                Web services are implemented with <strong>REST</strong> (Representational State Transfer) architectural styling.
                REST is a commonly used <strong>Application Programming Interface</strong> (API) that follows a specific set of guidelines and allows for the execution of CRUD operations; Create, Read, Update, and Delete.
            </p>
        </article>
        </div>
    );
}

export default Home;

