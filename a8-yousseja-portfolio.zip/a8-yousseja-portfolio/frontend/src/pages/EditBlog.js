import React, { useState } from 'react';
import { useNavigate } from "react-router-dom";
import { BiSave } from "react-icons/bi";

export const EditBlog = ({ blog }) => {
    const [entryNumber, setEntryNumber] = useState(blog.entryNumber);
    const [date, setDate] = useState(blog.date);
    const [entry, setEntry] = useState(blog.entry);

    const travel = useNavigate();

    const editBlog = async () => {

        const reply = await fetch (`/blogs/${blog._id}`, {
            method: 'PUT',
            body: JSON.stringify({
                entryNumber: entryNumber,
                date: date,
                entry: entry
            }),
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if(reply.status === 200){
            travel("/blogs")
            alert("Successfully published a new blog entry.");
        } else {
            const err = await reply.json();
            travel("/blogs")
            alert(`Could not update blog entry at this time. Status: ${reply.status}: ${err.Error}`);
        }
    };

    return (
        <>
        <h2>Edit a blog entry.</h2>
        <article>
            <p>Edit your blog entries' content, number, or date..</p>
            <table id="blogs">
                <caption>Edit an entry to the blog.</caption>
                <thead>
                </thead>                
                <tbody>
                    <tr>
                        <th>Entry Number</th>
                        <td>
                            <label htmlFor="entryNumber" className="required">
                                <input type="number" 
                                    value={entryNumber} 
                                    id="entryNumber" 
                                    name="entryNumber"
                                    onChange={n => setEntryNumber(n.target.value)} 
                                    required 
                                />
                            </label>
                        </td>
                    </tr>
                    <tr>                
                        <th>Date</th>
                        <td>
                            <label htmlFor="date" className="required">
                                <input type="date" 
                                id="date" 
                                name="date" 
                                value={date}
                                required
                                onChange={d => setDate(d.target.value)}
                                pattern="\d{2}-\d{2}-\d{2}"
                                />
                            </label>
                        </td>   
                    </tr>
                    <tr>
                        <th>Entry</th>
                        <td>
                            <label htmlFor="entry" className="required">
                                <input type="text" 
                                    value={entry} 
                                    id="entry" 
                                    name="entry"
                                    onChange={e => setEntry(e.target.value)} 
                                    required 
                                />
                            </label>
                        </td>  
                    </tr>
                </tbody>
            </table>
            <button id="submitBlog" className="wait" onClick={editBlog}> Save {< BiSave />} </button>
        </article>
        </>
    );
}

export default EditBlog;

