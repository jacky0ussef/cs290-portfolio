import React from 'react';
import ProductRow from '../components/ProductRow.js';

function Order({items}) {
    return (
        <div>
        <h2>Order</h2>
        <article>
            <p>Place an order now by selecting the quantity of each product and checking out!</p>
            <table>
                <caption>Our Products</caption>
                <thead>
                    <tr>
                        <th>Company</th>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                    </tr>
                </thead>
                <tbody>  
                    {items.map((product, index) =>
                        <ProductRow
                            option={product}
                            key={index}
                        />
                    )}
                </tbody>
            </table>
        </article>
        </div>
    );
}

export default Order;


