import React from 'react';

function Topics() {
    return (
        <div>
        <h2>Web Development Concepts</h2>
        <nav>
            <a href="#about_js" className="local">About JavaScript</a>
            <a href="#about_dom" className="local">About DOM</a>
        </nav>
        <article>
            <h3>Web Servers</h3>
            <p>The index is a common default file within a domain that is retrieved when a user does not explicitly specify a path.
                For example, URLs "google.com" and "google.com/index.html" are interpreted identically by a web server, resulting in the same resource being retrieved for each URL.
                Developers typically use index.html for their domain's home and landing page.
                Apache servers, which this website is hosted on, use "index.html" as their default landing page.
                Other server platforms may use different defaults, such as "default.html".</p>
            <p>There are many differences between a file's details on a web server and on a local computer. 
                In an Inspector tool, one can see that the Network's Request URLs are different.
                For a local file, the protocol is "file" with the destination of the file on the local computer. 
                On a web server, however, the request is a URL with an HTTPS protocol.
                Another notable difference is the information that is only found within a web server environment, such as cookie, connection, and host headers.</p>
            <p>HTTP status code 200 represents the successful retrieval of a request. 
                The favicon.ico file, which represents the browser tab's icon, is located within the domain's directory. 
                Thus, similarly to the site's index landing page, the server responds with a 200 code.
                In this case, the favicon is defaulted to the OSU logo because it is located within my directory.
                However, the main.js and main.css files do not hold the code because they are not located within the directory and thus not retrieved.
                These files have 404 status codes, which means that the requested resource was not found on the server.</p>
            <p>A URL is composed of two required components, the scheme and server/domain name, and four optional components, the port number, path, query parameter(s), and resource link.
                This website's URL is "https://web.engr.oregonstate.edu/~yousseja/a1-yousseja/"".
                The scheme is HTTPS, subdomain "web.engr.", domain "oregonstate.edu", and path "/~yousseja/a1-yousseja/".</p>
        </article>
        <article>
            <h3>Frontend Design</h3>
            <p><strong>Frontend design</strong> is the creation of a user interface for web applications. 
            This visual representation is intentionally tailored to be the optimum user experience for the goal of the webpage and creator. 
            The interactive experience includes the visual design and the graphical user-interface (GUI).
            There are many elements, such as color and typography scheme consistency, that are critical to the <strong>usability</strong> of the webpage.
            Usability measures the quality of a user's experience with a device and consists of specific components that are essential for achieving the goals of a device. </p>

            <h4>The five "E"s of Usability:</h4>
            <dl>
                <dt>Effective</dt>
                <dd>A usable website is effective at helping users meet their goal(s).</dd>
                <dt>Efficient</dt>
                <dd>A usable website is efficient, so users can perform tasks with the fewest number of steps.</dd>
                <dt>Easy</dt>
                <dd>A usable website is easy to navigate, where users can immediately determine how to locate their goal(s).</dd>
                <dt>Error-free</dt>
                <dd>A usable website is error-free, to avoid any issues/errors that prevent the user from completing their goal(s).</dd>
                <dt>Enjoyable/Engaging</dt>
                <dd>A usable website is enjoyable or engaging, so that users return in response to the overall experience.</dd>
            </dl>

            <p>Page layout tags are <strong>block-level</strong> elements, which separate content and are displayed with an opposing <strong>newline</strong> on each end.
                These tags are leveraged with corresponding styles that are usually applied with a style sheet.
                Tags are denoted similarly to other elements, starting and ending with "< >" and "</>" symbols, and the element name enclosed within.
                There are many page layout tags in a particular webpage including header, nav, and main tags, amongst others.
            </p>

            <p><strong>Anchors</strong> link one section or page to another using specific tags.
                The "nav" tag is utilized to move throughout a web application while the "a" tag links to another webpage.
                These tags include a "href" attribute to provide the destination of the link.
                Navigation tags include a link to an <strong>ID</strong> selector while anchor tags include an absolute or relative URL.
                An absolute URL is a complete webpage URL, including the protocol and domain.
                A relative URL points to a location relative to the current file, using specific syntax to navigate within and amongst directories.
            </p>

        </article>
        <article id="about_js">
            <h3>About JavaScript</h3>
            <p><strong>JavaScript</strong> contains six man data types: <strong>number</strong>, <strong>boolean</strong>, <strong>string</strong>, 
                <strong>symbol</strong>, <strong>special value</strong> (<strong>undefined</strong>/<strong>null</strong>), and <strong>object</strong>.
                Non-object data types are considered <strong>primitive types</strong>. Objects are represented as a set of name-value pairs.
                The actions used with objects are referred to as <strong>CRUD</strong>: <strong>Create</strong>/<strong>Update</strong>, <strong>Read</strong>,
                and <strong>Delete</strong>. Arrays are objects with sequential integers as the string property names. These are used to hold a certain group 
                of elements that can be of any JavaScript types, including object. <strong>JSON</strong> is utilized to exchange data between applications. 
                Its format is independent of any language, allowing programs to exchange data regardless of their programming language. "<strong>If</strong>",
                "<strong>switch</strong>", and <strong>ternary operator</strong> statements are found in JavaScript for completing <strong>conditionals</strong> 
                and are formatted similarly to other languages. Additionally, "<strong>while</strong>", "<strong>do while</strong>", and "<strong>for</strong>" statements 
                operate similarly for <strong>loop</strong> implementation. <strong>Object-oriented programming</strong> uses objects to represent <strong>identity</strong>,
                <strong>state</strong>, and <strong>behavior</strong>. JavaScript allows developers to create objects without declaring classes and perform CRUD actions.
            </p>
        </article>            
        <article id="about_dom">
            <h3>About DOM</h3>
            <p> Developers modify the <strong>Document Object Model (DOM)</strong> using JavaScript and <strong>Express</strong> to update 
                specific areas of HTML pages without the need for reloading the entire page. This is essential to building interactive web
                applications using <strong>event-driven programming</strong>. User <strong>events</strong> are captured by JavaScript 
                <strong>event handlers</strong>, which allow developers to program a variety of actions, including modifying 
                <strong>DOM nodes</strong> and sending HTTP requests to a web server.
            </p>
        </article>
        </div>
    );
}

export default Topics;
