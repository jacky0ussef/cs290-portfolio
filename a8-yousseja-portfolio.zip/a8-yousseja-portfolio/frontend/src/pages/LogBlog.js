import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import { Link } from 'react-router-dom';
import { BiPlusCircle } from 'react-icons/bi';

import BlogTable from '../components/BlogTable';

function LogBlog({ setBlogsLog }) {
    // Use the Navigate for redirection
    const travel = useNavigate();

    // Use state to bring in the data
    const [blogs, setBlogs] = useState([]);
    
    // RETRIEVE the entire list of blogs
    const loadBlogs = async () => {
        const reply = await fetch('/blogs');
        const blogsList = await reply.json();
        setBlogs(blogsList);
    } 

    // UPDATE a single blog
    const onEditBlog = async blog => {
        setBlogsLog(blog);
        travel("/edit-blog");
    }

    // DELETE a single blog  
    const onDeleteBlog = async _id => {
        const reply = await fetch(`/blogs/${_id}`, { method: 'DELETE' });
        if (reply.status === 204) {
            const getReply = await fetch('/blogs');
            const blogsList = await getReply.json();
            setBlogs(blogsList);
        } else {
            console.error(`Could not delete blog with _id ${_id} and error status code ${reply.status}`)
        }
    }

    // LOAD all the blogs
    useEffect(() => {
        loadBlogs();
    }, []);

    // DISPLAY the movies
    return (
        <div>
            <h2>Blogs</h2>
            <p><Link class="blogButton" id="addBlog" to="../add-blog"> { <BiPlusCircle/> } </Link></p>
            <article>
                <p>Welcome to my tech blog! I am a Computer Science student at Oregon State University and have a passion for all things tech.</p>
                <BlogTable 
                    blogs={blogs} 
                    editBlogs ={onEditBlog} 
                    deleteBlogs ={onDeleteBlog} 
                />
            </article>
        </div>
    );
}

export default LogBlog;

                              