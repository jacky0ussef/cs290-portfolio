import React, { useState } from 'react';
import { useNavigate } from "react-router-dom";
import { BiSave } from "react-icons/bi";

export const CreateBlog = () => {
    const [entryNumber, setEntryNumber] = useState('0');
    const [date, setDate] = useState('');
    const [entry, setEntry] = useState('');

    const travel = useNavigate();

    const addBlog = async () => {
        const newBlog = { entryNumber, date, entry };

        const reply = await fetch ('/blogs', {
            method: 'POST',
            body: JSON.stringify(newBlog),
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if(reply.status === 201){
            alert("Successfully published a new blog entry.");
        } else {
            alert("Could not add blog entry at this time.");
        }
        travel("/blogs");
    };

    return (
        <>
        <h2>Complete a blog entry.</h2>
        <article>
            <p>Enter your blog along with the entry's number and date.</p>
            <table id="blogs">
                <caption>Add an entry to the blog.</caption>
                <thead>
                </thead>
                <tbody>
                    <tr>
                        <th>Entry Number</th>
                        <td>
                            <label htmlFor="entryNumber" className="required">
                                <input type="number" 
                                    value={entryNumber} 
                                    id="entryNumber" 
                                    name="entryNumber"
                                    onChange={n => setEntryNumber(n.target.value)} 
                                    required 
                                    autoFocus
                                />
                            </label>
                        </td>
                    </tr>
                    <tr>                
                        <th>Date</th>
                        <td>
                            <label htmlFor="date" className="required">
                                <input type="date" 
                                id="date" 
                                name="date" 
                                value={date}
                                required
                                onChange={d => setDate(d.target.value)}
                                pattern="\d{2}-\d{2}-\d{2}"
                                />
                            </label>
                        </td>   
                    </tr>
                    <tr>
                        <th>Entry</th>
                        <td>
                            <label htmlFor="entry" className="required">
                                <textarea type="text" 
                                    value={entry} 
                                    id="entry" 
                                    name="entry"
                                    onChange={e => setEntry(e.target.value)} 
                                    required />
                            </label>
                        </td>  
                    </tr>
                </tbody>
            </table>
            <button id="submitBlog" className="wait" onClick={addBlog}> Save {< BiSave />} </button>
            </article>
        </>
    );
}

export default CreateBlog;

