import React from 'react';
import ImageGallery from 'react-image-gallery';

const photos = [
    {
        original: 'images/weather-app.jpeg',
        thumbnail: 'images/weather-app.jpeg',
        description: `Swift iPhone weather application.`,
        originalHeight: '500px',
    },    
    {
        original: 'images/calculator-app.jpeg',
        thumbnail: 'images/calculator-app.jpeg',
        description: `Swift iPhone calculator application.`,
        originalHeight: '500px',
    },    
    {
        original: 'images/trivia-webpage.jpeg',
        thumbnail: 'images/trivia-webpage.jpeg',
        description: `Randomized trivia game playable as a web application.`,
        originalHeight: '500px',
    },    
    {
        original: 'images/pizza-website.jpeg',
        thumbnail: 'images/pizza-website.jpeg',
        description: `Redesigning local pizza company's locations page (for creative purposes only).`,
        originalHeight: '500px',
    },    
    {
        original: 'images/checkers-board-console.jpeg',
        thumbnail: 'images/checkers-board-console.jpeg',
        description: `Console-playable, two-person checkers game.`,
        originalHeight: '450px',
    },    
    {
        original: 'images/console-maze-solution.jpeg',
        thumbnail: 'images/console-maze-solution.jpeg',
        description: `Console maze solver with solution illustration.`,
        originalHeight: '500px',
    },    
    {
        original: 'images/golf-cart-road-mexico.jpeg',
        thumbnail: 'images/golf-cart-road-mexico.jpeg',
        description: `Solo golf cart touring a remote Mexican island.`,
        originalHeight: '500px',
    },    
    {
        original: 'images/miata-car.jpeg',
        thumbnail: 'images/miata-car.jpeg',
        description: `Years ago I began building and selling track cars.`,
        originalHeight: '500px',
    },    
    {
        original: 'images/rock-climbing-on-wall.jpeg',
        thumbnail: 'images/rock-climbing-on-wall.jpeg',
        description: `I really enjoy spending weekends rock climbing.`,
        originalHeight: '500px',
    },    
    {
        original: 'images/car-campfire-camping.jpeg',
        thumbnail: 'images/car-campfire-camping.jpeg',
        description: `One of my favorite hobbies is camping in remote nature.`,
        originalHeight: '500px',
    },
]

function Gallery() {
    return (
        <div>
        <h2>Gallery</h2>
            <article>

                <ImageGallery items={photos} />

            </article>
        </div>
    );
}

export default Gallery;

