import React, { useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

// data
import products from './data/products.js';

// components/pages
import Nav from './components/Nav.js';
import Home from './pages/Home.js';
import Topics from './pages/Topics.js';
import Gallery from './pages/Gallery.js';
import Staff from './pages/Staff.js';
import Order from './pages/Order.js';
import CreateBlog from './pages/CreateBlog.js';
import EditBlog from './pages/EditBlog.js';

import LogBlog from './pages/LogBlog.js';
// import ContactPage from './pages/ContactPage.js'

// styles
import './App.css';

function App() {
  const [blogNow, setBlogsNow] = useState([])
  return (
    <div>
      <BrowserRouter>

        <header>
          <h1>Jack Youssef</h1>
        </header>

        <Nav />

        <main>
          <section>
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/blogs" element={<LogBlog setBlogsLog={setBlogsNow} />} />
                <Route path="/topics" element={<Topics />} />
                <Route path="/gallery" element={<Gallery />} /> 
                <Route path="/staff" element={<Staff />} /> 
                <Route path="/order" element={<Order items={products}/>} /> 

                <Route path="/add-blog" element={<CreateBlog />} />
                <Route path="/edit-blog" element={<EditBlog blog={blogNow} />} />
            </Routes>
          </section>
        </main>
        
        <footer>
          <p><cite>&copy; 2023 Jack Youssef</cite></p>
        </footer>
        
        </BrowserRouter>
      </div>
    );
  }

export default App;
