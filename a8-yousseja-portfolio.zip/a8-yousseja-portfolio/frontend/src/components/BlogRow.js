import React from 'react';
import { RiEditLine, RiDeleteBin2Line } from 'react-icons/ri';

function BlogRow ({ blog, editBlog, deleteBlog }) {
    return (
        <tr>
            <td title="What is this blog's entry number?">{blog.entryNumber}</td>
            <td title="What is this blog entry's date?">{blog.date.slice(0,10)}</td>
            <td title="Complete your blog entry here.">{blog.entry}</td>
            <td><i><RiEditLine class="blogButton" onClick={() => editBlog(blog)} title="You can edit this blog entry on another page."></RiEditLine></i></td>
            <td><i><RiDeleteBin2Line class="blogButton" onClick={() => deleteBlog(blog._id)} title="Deleting a blog entry is permanent."></RiDeleteBin2Line></i></td>
        </tr>
    );
}

export default BlogRow;
