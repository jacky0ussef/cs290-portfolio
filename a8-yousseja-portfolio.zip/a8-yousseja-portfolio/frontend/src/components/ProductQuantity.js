import React, { useState } from 'react';
import {GrSubtractCircle, GrAddCircle} from 'react-icons/gr';

function ProductQuantity() {
    const [amount, setAmount] = useState(0);

    const add = () => setAmount(amount === 10 ? amount : amount + 1)
    const remove = () => setAmount(amount === 0 ? 0 : amount - 1)
    return (
        <div>
        <GrSubtractCircle onClick={remove} />
        <span> {amount} </span>
        <GrAddCircle onClick={add} />
        </div>
    );
}

export default ProductQuantity;

