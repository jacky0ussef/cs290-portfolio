import React from 'react';
import ProductQuantity from './ProductQuantity';

function ProductRow({option}) {
    return (
        <tr>
            <td>{option.product}</td>
            <td>{option.company}</td>
            <td>{option.price.toLocaleString('en-US', {style: 'currency', currency: 'USD'})}</td>
            <td><ProductQuantity /></td>
        </tr>
    );
}

export default ProductRow;

