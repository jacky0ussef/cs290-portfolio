import React from 'react';
import BlogRow from './BlogRow';

function BlogTable ({ blogs, editBlogs, deleteBlogs }) {
    return (
        <table id="blogs">
            <caption>Create and edit blog entries.</caption>
            <thead>
                <tr>
                    <th id="blogTableSmall">Entry Number</th>
                    <th id="blogTableSmall">Date</th>
                    <th id="blogTableLarge">Entry</th>
                    <th id="blogTableMedium">Edit</th>
                    <th id="blogTableMedium">Delete</th>
                </tr>
            </thead>
            <tbody>
                {blogs.map((blog, i) => 
                    <BlogRow 
                        blog={blog} 
                        key={i}
                        editBlog={editBlogs}
                        deleteBlog={deleteBlogs} 
                    />)}
            </tbody>
        </table>
    );
}

export default BlogTable;
