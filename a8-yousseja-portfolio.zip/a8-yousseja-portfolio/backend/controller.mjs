import 'dotenv/config';
import express from 'express';
import * as blogs from './model.mjs';

const PORT = process.env.PORT;
const app = express();
app.use(express.json());  // REST needs JSON MIME type.


// CREATE controller ******************************************
app.post ('/blogs', (req,res) => { 
    blogs.createBlog(
        req.body.entryNumber, 
        req.body.date, 
        req.body.entry
        )
        .then(blog => {
            res.status(201).json(blog);
        })
        .catch(error => {
            console.log(error);
            res.status(400).json({ error: 'Failed to create a blog entry.' });
        });
});

// RETRIEVE controller ****************************************************
app.get('/blogs', (req, res) => {
    blogs.retrieveBlogs()
        .then(blog => { 
            if (blog !== null) {
                res.json(blog);
            } else {
                res.status(404).json({ Error: 'Blog entry not found.' });
            }         
         })
        .catch(error => {
            console.log(error);
            res.status(400).json({ Error: 'Failed to retrieve blog entry.' });
        });
});

// RETRIEVE by ID controller
app.get('/blogs/:_id', (req, res) => {
    blogs.retrieveBlogByID(req.params._id)
    .then(blog => { 
        if (blog !== null) {
            res.json(blog);
        } else {
            res.status(404).json({ Error: 'Blog entry not found.' });
        }         
     })
    .catch(error => {
        console.log(error);
        res.status(400).json({ Error: 'Failed to retrieve blog entry.' });
    });

});

// UPDATE controller ************************************
app.put('/blogs/:_id', (req, res) => {
    blogs.updateBlog(
        req.params._id, 
        req.body.entryNumber, 
        req.body.date, 
        req.body.entry
    )
    .then(blog => {
        res.status(200).json(blog);
    })
    .catch(error => {
        console.log(error);
        res.status(400).json({ error: 'Failed to update blog entry.' });
    });
});

// DELETE Controller ******************************
app.delete('/blogs/:_id', (req, res) => {
    blogs.deleteBlogById(req.params._id)
        .then(deletedCount => {
            if (deletedCount === 1) {
                res.status(204).send();
            } else {
                res.status(404).json({ Error: 'Blog entry no longer exists.' });
            }
        })
        .catch(error => {
            console.error(error);
            res.send({ error: 'Failed to delete blog entry.' });
        });
});


app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}...`);
});

