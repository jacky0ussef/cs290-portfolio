// Import dependencies.
import mongoose from 'mongoose';
import 'dotenv/config';


// Connect based on the .env file parameters.
mongoose.connect(
    process.env.MONGODB_CONNECT_STRING,
    { useNewUrlParser: true }
);
const dataB = mongoose.connection;


// Confirm that the database has connected and print a message in the console.
dataB.once("open", (err) => {
    if(err){
        res.status(500).json({ error: '500: Failed to connect to the server at this time.' });
    } else  {
        console.log('Connected to MongoDB Blogs collection using Mongoose.');
    }
});


// SCHEMA: Define the collection's schema.
const blogSchema = mongoose.Schema({
    entryNumber:    { type: Number, required: true, default: 0 },
	date:           { type: Date, required: true, min: '2022-01-01', default: Date.now },
    entry:          { type: String, required: true }
});


// Compile the model from the schema.
const Blog = mongoose.model("Blog", blogSchema);


// CREATE model *****************************************
const createBlog = async (entryNumber, date, entry) => {
    const blog = new Blog ({ 
        entryNumber: entryNumber, 
        date: date, 
        entry: entry 
    });
    return blog.save();
}

// RETRIEVE models *****************************************
// Retrieve based on a filter and return a promise.
const retrieveBlogs = async () => {
    const query = Blog.find();
    return query.exec();
}

// RETRIEVE by ID
const retrieveBlogByID = async (id) => {
    const query = Blog.findById(id);
    return query.exec();
}

// DELETE model based on _id  *****************************************
const deleteBlogById = async (_id) => {
    const result = await Blog.deleteOne({_id: _id});
    return result.deletedCount;
};

// UPDATE model *****************************************************
const updateBlog = async (id, entryNumber, date, entry) => {
    const result = await Blog.replaceOne({_id: id }, {
        entryNumber: entryNumber, 
        date: date, 
        entry: entry
    });
    return { 
        id: id, 
        entryNumber: entryNumber, 
        date: date, 
        entry: entry 
    }
}


// Export our variables for use in the controller file.
export { createBlog, retrieveBlogs, retrieveBlogByID, updateBlog, deleteBlogById }
